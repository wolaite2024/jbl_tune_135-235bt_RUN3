One Click Pack Usage
(More detailed explanation please refer to 'MPPG Tool Chain User Guide.docx'.)
 
1. Put bin files and flash map.ini into specified sub-folder of 'OneClickPack' folder.
2. Click 'One-Click Pack for OTA' on menu bar.
3. Load 'OneClickPack' folder and click 'Auto Pack'.